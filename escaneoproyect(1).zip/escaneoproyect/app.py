from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import os

app = Flask(__name__)
app.secret_key = "clave_secreta_bro"

DB_FILE = "users.db"
ADMIN_PASS_FILE = "admin_pass.txt"

# ----------------------------------------------------
# Función para obtener la contraseña del archivo externo
# ----------------------------------------------------
def get_admin_password():
    if os.path.exists(ADMIN_PASS_FILE):
        with open(ADMIN_PASS_FILE, "r", encoding="utf-8") as f:
            return f.readline().strip()
    else:
        # Si no existe, crear el archivo con contraseña por defecto
        default_password = "1234"
        with open(ADMIN_PASS_FILE, "w", encoding="utf-8") as f:
            f.write(default_password)
        print(f"[INFO] Archivo {ADMIN_PASS_FILE} creado con contraseña por defecto: {default_password}")
        return default_password

ADMIN_PASSWORD = get_admin_password()

# ----------------------------------------------------
# Crear base de datos si no existe
# ----------------------------------------------------
if not os.path.exists(DB_FILE):
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("""
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT,
                password TEXT
            )
        """)
        conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", ("admin", ADMIN_PASSWORD))
        print("[INFO] Base de datos creada con usuario admin.")

# ----------------------------------------------------
# Rutas principales
# ----------------------------------------------------
@app.route('/')
def index():
    if "user" in session:
        return redirect(url_for("home"))
    return redirect(url_for("login"))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"].strip()

        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
            user = cursor.fetchone()

        if user:
            session["user"] = username
            flash("Inicio de sesión exitoso", "success")
            return redirect(url_for("home"))
        else:
            flash("Usuario o contraseña incorrectos", "error")

    return render_template("login.html")

@app.route('/home')
def home():
    if "user" not in session:
        return redirect(url_for("login"))
    return render_template("home.html", username=session["user"])

@app.route('/logout')
def logout():
    session.pop("user", None)
    flash("Sesión cerrada correctamente", "info")
    return redirect(url_for("login"))

# ----------------------------------------------------
# Iniciar servidor
# ----------------------------------------------------
if __name__ == '__main__':
    print(f"[INFO] Contraseña del admin leída desde '{ADMIN_PASS_FILE}'")
    app.run(debug=True)
