import os
import sqlite3
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash, g

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "users.db")

# Archivos posibles donde puede estar la contraseña admin (orden de prioridad)
SECRET_FILE = os.path.join(BASE_DIR, "secret.brokey")    # TU archivo actual
ADMIN_PASS_FILE = os.path.join(BASE_DIR, "admin_pass.txt")  # fallback

app = Flask(__name__)
app.secret_key = "clave_secreta_123"  # cámbiala si quieres

# -------------------------
# Inicializar DB si hace falta
# -------------------------
def init_db():
    if not os.path.exists(DB_PATH):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("""
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                created_at TEXT NOT NULL
            )
        """)
        conn.commit()
        conn.close()
        print("[OK] Base de datos creada correctamente.")
    else:
        print("[OK] Base de datos ya existe.")

# -------------------------
# Leer contraseña admin (SECRET_FILE > ADMIN_PASS_FILE > crear admin_pass.txt)
# -------------------------
def load_admin_password():
    # 1) Si existe secret.brokey usarla
    if os.path.exists(SECRET_FILE):
        try:
            with open(SECRET_FILE, "r", encoding="utf-8") as f:
                pw = f.readline().strip()
                if pw:
                    print(f"[INFO] Contraseña admin cargada desde '{os.path.basename(SECRET_FILE)}'")
                    return pw
        except Exception as e:
            print(f"[WARN] Error leyendo {SECRET_FILE}: {e}")

    # 2) Si no, intentar admin_pass.txt
    if os.path.exists(ADMIN_PASS_FILE):
        try:
            with open(ADMIN_PASS_FILE, "r", encoding="utf-8") as f:
                pw = f.readline().strip()
                if pw:
                    print(f"[INFO] Contraseña admin cargada desde '{os.path.basename(ADMIN_PASS_FILE)}'")
                    return pw
        except Exception as e:
            print(f"[WARN] Error leyendo {ADMIN_PASS_FILE}: {e}")

    # 3) Si ninguno existe, crear admin_pass.txt con contraseña por defecto '1234'
    try:
        with open(ADMIN_PASS_FILE, "w", encoding="utf-8") as f:
            f.write("1234")
        print(f"[WARN] No se encontró {os.path.basename(SECRET_FILE)} ni {os.path.basename(ADMIN_PASS_FILE)}. Se creó '{os.path.basename(ADMIN_PASS_FILE)}' con contraseña por defecto '1234'.")
    except Exception as e:
        print(f"[ERROR] No se pudo crear {ADMIN_PASS_FILE}: {e}")
    return "1234"

ADMIN_PASS = load_admin_password()

# -------------------------
# DB helpers
# -------------------------
def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DB_PATH)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

# -------------------------
# Rutas
# -------------------------
@app.route("/")
def index():
    if "admin" in session:
        return redirect(url_for("admin_panel"))
    if "user" in session:
        return redirect(url_for("home"))
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        if not username or not password:
            flash("Todos los campos son obligatorios.", "danger")
            return redirect(url_for("register"))

        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        try:
            c.execute(
                "INSERT INTO users (username, password, status, created_at) VALUES (?, ?, 'pending', ?)",
                (username, password, datetime.utcnow().isoformat())
            )
            conn.commit()
            flash("Cuenta creada. Espera aprobación del administrador.", "info")
            print(f"[INFO] Nuevo registro '{username}' -> pending")
        except sqlite3.IntegrityError:
            flash("Ese usuario ya existe.", "danger")
            print(f"[WARN] Intento registro duplicado: {username}")
        finally:
            conn.close()
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()

        # admin login (usuario 'admin' comparado con ADMIN_PASS)
        if username.lower() == "admin" and password == ADMIN_PASS:
            session.clear()
            session["admin"] = True
            flash("Sesión de administrador iniciada.", "success")
            print("[INFO] Admin inició sesión.")
            return redirect(url_for("admin_panel"))

        # usuario normal
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT id, status FROM users WHERE username=? AND password=?", (username, password))
        row = c.fetchone()
        conn.close()

        if row:
            uid, status = row
            if status == "approved":
                session.clear()
                session["user"] = username
                flash(f"Bienvenido, {username}.", "success")
                print(f"[INFO] Usuario '{username}' inició sesión (approved).")
                return redirect(url_for("home"))
            elif status == "pending":
                flash("Tu cuenta está pendiente de aprobación.", "warning")
                print(f"[INFO] Usuario '{username}' intentó login (pending).")
            else:
                flash("Tu cuenta fue rechazada.", "danger")
                print(f"[INFO] Usuario '{username}' intentó login (rejected).")
        else:
            flash("Credenciales incorrectas.", "danger")
            print(f"[WARN] Login fallido para usuario: {username}")

    return render_template("login.html")

@app.route("/home")
def home():
    if "user" not in session:
        flash("Inicia sesión primero.", "warning")
        return redirect(url_for("login"))
    return render_template("home.html", user=session.get("user"))

@app.route("/admin", methods=["GET", "POST"])
def admin_panel():
    if "admin" not in session:
        flash("Acceso denegado. Solo admin.", "danger")
        return redirect(url_for("login"))

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    if request.method == "POST":
        uid = request.form.get("id")
        action = request.form.get("action")
        if uid and action:
            if action == "approve":
                c.execute("UPDATE users SET status='approved' WHERE id=?", (uid,))
                conn.commit()
                flash("Usuario aprobado.", "success")
                print(f"[ADMIN] Aprobado id={uid}")
            elif action == "reject":
                c.execute("UPDATE users SET status='rejected' WHERE id=?", (uid,))
                conn.commit()
                flash("Usuario rechazado.", "info")
                print(f"[ADMIN] Rechazado id={uid}")

    c.execute("SELECT id, username, status, created_at FROM users ORDER BY created_at DESC")
    users = c.fetchall()
    conn.close()
    return render_template("admin.html", users=users)

@app.route("/logout")
def logout():
    who = "admin" if "admin" in session else session.get("user")
    session.clear()
    flash("Sesión cerrada.", "info")
    print(f"[INFO] Sesión cerrada: {who}")
    return redirect(url_for("login"))

# -------------------------
# Main
# -------------------------
if __name__ == "__main__":
    init_db()
    print(f"[INFO] ADMIN password loaded (priority: secret.brokey then admin_pass.txt).")
    app.run(host="127.0.0.1", port=5000, debug=True)
